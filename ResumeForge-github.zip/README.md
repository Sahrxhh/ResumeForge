# ResumeForge

ATS-friendly resume builder. Fill details, get LaTeX code and a PDF. 4 templates, colours, fonts.

## Use / Install
Open the live link (GitHub Pages), then tap **Install App** (or Chrome menu > Add to Home screen).
After the first visit it also works offline.

## Deploy
1. Push these files to a GitHub repo (branch `main`).
2. Settings > Pages > Source: **GitHub Actions**.
3. Your link: `https://<username>.github.io/<repo>/`

## Get an APK
Open your live link at https://www.pwabuilder.com, choose Android, download the package.
